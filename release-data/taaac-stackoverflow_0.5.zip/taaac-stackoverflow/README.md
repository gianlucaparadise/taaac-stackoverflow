# taaac-stackoverflow
Trick accepted answer auditor. A Chrome extension for StackOverflow.
